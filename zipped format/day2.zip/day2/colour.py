def green():
    print("go green")
    
def blue():
    print("cool blue")
    